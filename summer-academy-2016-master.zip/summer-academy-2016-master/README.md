# NGCM Summer Academy 2016

Currently this is for gathering material ahead of the SA: afterwards it should be public, and give links to all open material.
